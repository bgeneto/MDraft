Tauri 2 Markdown editor icon assets

Use icon.png as the 1024x1024 source, or copy this folder to src-tauri/icons.
Includes PNG variants, multi-size Windows ICO, and Apple ICNS.

If you prefer Tauri CLI to regenerate platform assets from icon.png:
  npm run tauri icon src-tauri/icons/icon.png
